package application;

public class Location extends General_Info{
	
	public Location(String argN, String argD) {
		super(argN,argD);
	}

}

package application;

public class Category extends Name{
	
	public Category(String arg) {
		super(arg);
	
	}

}

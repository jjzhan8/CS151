package model;

public abstract interface DataProcess {
	public String saveToCsv();
	
}
